package com.shiju.barservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BarServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
