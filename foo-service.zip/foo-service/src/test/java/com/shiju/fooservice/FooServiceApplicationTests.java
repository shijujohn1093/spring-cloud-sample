package com.shiju.fooservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FooServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
